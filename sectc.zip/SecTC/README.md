# SETC-SecTelComm
Secure Electronic Tele Communication
